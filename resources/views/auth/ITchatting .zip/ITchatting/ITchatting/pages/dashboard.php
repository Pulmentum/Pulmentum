<!DOCTYPE html>
					<html>
<!-- Mirrored from light.pinsupreme.com/apps_full_chat.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 25 Dec 2017 17:49:56 GMT -->
<head>
						<title>Admin Dashboard HTML Template</title>
					<meta charset="utf-8">
					<meta content="ie=edge" http-equiv="x-ua-compatible">
					<meta content="template language" name="keywords">
					<meta content="Tamerlan Soziev" name="author">
					<meta content="Admin dashboard html template" name="description">
					<meta content="width=device-width, initial-scale=1" name="viewport">
					<link href="favicon.png" rel="shortcut icon">
					<link href="apple-touch-icon.png" rel="apple-touch-icon">
					<link href="../fast.fonts.net/cssapi/487b73f1-c2d1-43db-8526-db577e4c822b.css" rel="stylesheet" type="text/css">
					<link href="bower_components/select2/dist/css/select2.min.css" rel="stylesheet">
					<link href="bower_components/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
					<link href="bower_components/dropzone/dist/dropzone.css" rel="stylesheet">
					<link href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
					<link href="bower_components/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet">
					<link href="bower_components/perfect-scrollbar/css/perfect-scrollbar.min.css" rel="stylesheet">
					<link href="css/main4e09.css?version=3.7.0" rel="stylesheet">
					</head>
					<body>
						<div class="all-wrapper menu-side no-padding-content">
						<div class="layout-w">
					<!--------------------
START - Mobile Menu
-------------------->
					<div class="menu-mobile menu-activated-on-click color-scheme-dark">
						<div class="mm-logo-buttons-w">
						<a class="mm-logo" href="index.html">
						<img src="img/logo.png">
					<span>Clean Admin</span>
					</a>
					<div class="mm-buttons">
						<div class="content-panel-open">
						<div class="os-icon os-icon-grid-circles">
					</div>
					</div>
					<div class="mobile-menu-trigger">
						<div class="os-icon os-icon-hamburger-menu-1">
					</div>
					</div>
					</div>
					</div>
					<div class="menu-and-user">
						<div class="logged-user-w">
						<div class="avatar-w">
						<img alt="" src="img/avatar1.jpg">
					</div>
					<div class="logged-user-info-w">

						<div class="logged-user-name">Maria Gomez</div>
					<div class="logged-user-role">Administrator</div>
					</div>
					</div>
					<!--------------------
START - Mobile Menu List
-------------------->
					<ul class="main-menu">
						<li class="has-sub-menu">
						<a href="index.html">
						<div class="icon-w">
						<div class="os-icon os-icon-window-content">
					</div>
					</div>
					<span>Dashboard</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="index.html">Dashboard 1</a>
					</li>
					<li>
						<a href="apps_support_dashboard.html">Dashboard 2 <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_projects.html">Dashboard 3</a>
					</li>
					<li>
						<a href="apps_bank.html">Dashboard 4 <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="layouts_menu_top_image.html">Dashboard 5</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-hierarchy-structure-2">
					</div>
					</div>
					<span>Menu Styles</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="layouts_menu_side.html">Side Menu Light</a>
					</li>
					<li>
						<a href="layouts_menu_side_dark.html">Side Menu Dark</a>
					</li>
					<li>
						<a href="apps_bank.html">Side Menu V2 <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_pipeline.html">Side &amp; Top Dark</a>
					</li>
					<li>
						<a href="apps_projects.html">Side &amp; Top <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="layouts_menu_side_compact.html">Compact Side Menu</a>
					</li>
					<li>
						<a href="layouts_menu_side_compact_dark.html">Compact Menu Dark</a>
					</li>
					<li>
						<a href="layouts_menu_top.html">Top Menu Light</a>
					</li>
					<li>
						<a href="layouts_menu_top_dark.html">Top Menu Dark</a>
					</li>
					<li>
						<a href="layouts_menu_top_image.html">Top Menu Image</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-delivery-box-2">
					</div>
					</div>
					<span>Applications</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="apps_email.html">Email Application</a>
					</li>
					<li>
						<a href="apps_support_dashboard.html">Support Dashboard <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_support_index.html">Tickets Index <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_projects.html">Projects List</a>
					</li>
					<li>
						<a href="apps_bank.html">Banking <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_full_chat.html">Chat Application</a>
					</li>
					<li>
						<a href="apps_todo.html">To Do Application <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="misc_chat.html">Popup Chat</a>
					</li>
					<li>
						<a href="apps_pipeline.html">CRM Pipeline</a>
					</li>
					<li>
						<a href="rentals_index_grid.html">Property Listing <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="misc_calendar.html">Calendar</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-newspaper">
					</div>
					</div>
					<span>Pages</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="misc_invoice.html">Invoice</a>
					</li>
					<li>
						<a href="rentals_index_grid.html">Property Listing <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="misc_charts.html">Charts</a>
					</li>
					<li>
						<a href="auth_login.html">Login</a>
					</li>
					<li>
						<a href="auth_register.html">Register</a>
					</li>
					<li>
						<a href="auth_lock.html">Lock Screen</a>
					</li>
					<li>
						<a href="misc_pricing_plans.html">Pricing Plans</a>
					</li>
					<li>
						<a href="misc_error_404.html">Error 404</a>
					</li>
					<li>
						<a href="misc_error_500.html">Error 500</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-pencil-12">
					</div>
					</div>
					<span>UI Kit</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="uikit_modals.html">Modals</a>
					</li>
					<li>
						<a href="uikit_alerts.html">Alerts</a>
					</li>
					<li>
						<a href="uikit_grid.html">Grid</a>
					</li>
					<li>
						<a href="uikit_progress.html">Progress</a>
					</li>
					<li>
						<a href="uikit_popovers.html">Popover</a>
					</li>
					<li>
						<a href="uikit_tooltips.html">Tooltips</a>
					</li>
					<li>
						<a href="uikit_buttons.html">Buttons</a>
					</li>
					<li>
						<a href="uikit_dropdowns.html">Dropdowns</a>
					</li>
					<li>
						<a href="uikit_typography.html">Typography</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-user-male-circle">
					</div>
					</div>
					<span>Users</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="users_profile_big.html">Big Profile</a>
					</li>
					<li>
						<a href="users_profile_small.html">Compact Profile</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-tasks-checked">
					</div>
					</div>
					<span>Forms</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="forms_regular.html">Regular Forms</a>
					</li>
					<li>
						<a href="forms_validation.html">Form Validation</a>
					</li>
					<li>
						<a href="forms_wizard.html">Form Wizard</a>
					</li>
					<li>
						<a href="forms_uploads.html">File Uploads</a>
					</li>
					<li>
						<a href="forms_wisiwig.html">Wisiwig Editor</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-grid-squares">
					</div>
					</div>
					<span>Tables</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="tables_regular.html">Regular Tables</a>
					</li>
					<li>
						<a href="tables_datatables.html">Data Tables</a>
					</li>
					<li>
						<a href="tables_editable.html">Editable Tables</a>
					</li>
					</ul>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<div class="os-icon os-icon-robot-1">
					</div>
					</div>
					<span>Icons</span>
					</a>
					<ul class="sub-menu">
						<li>
						<a href="icon_fonts_simple_line_icons.html">Simple Line Icons</a>
					</li>
					<li>
						<a href="icon_fonts_themefy.html">Themefy Icons</a>
					</li>
					<li>
						<a href="icon_fonts_picons_thin.html">Picons Thin</a>
					</li>
					<li>
						<a href="icon_fonts_dripicons.html">Dripicons</a>
					</li>
					<li>
						<a href="icon_fonts_eightyshades.html">Eightyshades</a>
					</li>
					<li>
						<a href="icon_fonts_entypo.html">Entypo</a>
					</li>
					<li>
						<a href="icon_fonts_font_awesome.html">Font Awesome</a>
					</li>
					<li>
						<a href="icon_fonts_foundation_icon_font.html">Foundation Icon Font</a>
					</li>
					<li>
						<a href="icon_fonts_metrize_icons.html">Metrize Icons</a>
					</li>
					<li>
						<a href="icon_fonts_picons_social.html">Picons Social</a>
					</li>
					<li>
						<a href="icon_fonts_batch_icons.html">Batch Icons</a>
					</li>
					<li>
						<a href="icon_fonts_dashicons.html">Dashicons</a>
					</li>
					<li>
						<a href="icon_fonts_typicons.html">Typicons</a>
					</li>
					<li>
						<a href="icon_fonts_weather_icons.html">Weather Icons</a>
					</li>
					<li>
						<a href="icon_fonts_light_admin.html">Light Admin</a>
					</li>
					</ul>
					</li>
					</ul>
					<!--------------------
END - Mobile Menu List
-------------------->
					<div class="mobile-menu-magic">
						<h4>Light Admin</h4>
					<p>Clean Bootstrap 4 Template</p>
					<div class="btn-w">
						<a class="btn btn-white btn-rounded" href="https://themeforest.net/item/light-admin-clean-bootstrap-dashboard-html-template/19760124?ref=Osetin" target="_blank">Purchase Now</a>
					</div>
					</div>
					</div>
					</div>
					<!--------------------
END - Mobile Menu
-------------------->
					<!--------------------
START - Menu side compact
-------------------->
					<div class="desktop-menu menu-side-compact-w menu-activated-on-hover color-scheme-dark">
						<div class="logo-w">
						<a class="logo" href="index.html">
						<img src="img/logo.png">
					</a>
					</div>
					<?php
         //function recuperation info fournisseur
            function info_recuper_user_connect(){
             $infos = array();
             $query = mysql_query("SELECT * FROM users WHERE username = '{$_SESSION['username']}'");
             while($rows = mysql_fetch_assoc($query)){
                 $infos[]=$rows;
             }
             return $infos;
            }
            $infos = info_recuper_user_connect();
            foreach ($infos as $info) {
                $_SESSION['firstname'] = $info['firstname'];
                $_SESSION['lastname'] = $info['lastname'];
                $_SESSION['priority'] = $info['priority'];
                $_SESSION['img'] = $info['imageuser'];
            }
        ?>
					<div class="menu-and-user">
						<div class="logged-user-w">
						<div class="logged-user-i">
						<div class="avatar-w">
						<img alt="" src="<?PHP echo $_SESSION['img']?>">
					</div>
					<div class="logged-user-menu">
						<div class="logged-user-avatar-info">
						<div class="avatar-w">
						<img alt="" src="<?PHP echo $_SESSION['img']?>">
					</div>
					<div class="logged-user-info-w">
						<div class="logged-user-name"><a><?php echo $_SESSION['firstname'].' '.$_SESSION['lastname'] ?></a>
	<a href="index.php?page=logout&&usersession=<?php echo $_SESSION['username']?>"><i class="glyphicon glyphicon-log-out"></i></a></div>
					</div>
					</div>
					<div class="bg-icon">
						<i class="os-icon os-icon-wallet-loaded">
					</i>
					</div>
					<ul>
						<li>
						<a href="apps_email.html">
						<i class="os-icon os-icon-mail-01">
					</i>
					<span>Incoming Mail</span>
					</a>
					</li>
					<li>
						<a href="users_profile_big.html">
						<i class="os-icon os-icon-user-male-circle2">
					</i>
					<span>Profile Details</span>
					</a>
					</li>
					<li>
						<a href="users_profile_small.html">
						<i class="os-icon os-icon-coins-4">
					</i>
					<span>Billing Details</span>
					</a>
					</li>
					<li>
						<a href="#">
						<i class="os-icon os-icon-others-43">
					</i>
					<span>Notifications</span>
					</a>
					</li>
					<li>
						<a href="index.php?page=logout&&usersession=<?php echo $_SESSION['username']?>">
						<i class="os-icon os-icon-signs-11">
					</i>
					<span>Logout</span>
					</a>
					</li>
					</ul>
					</div>
					</div>
					</div>
					<ul class="main-menu">
						<li class="has-sub-menu">
						<a href="index.html">
						<div class="icon-w">
						<i class="os-icon os-icon-window-content">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Dashboard</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-window-content">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="index.html">Dashboard 1</a>
					</li>
					<li>
						<a href="apps_support_dashboard.html">Dashboard 2 <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_projects.html">Dashboard 3</a>
					</li>
					<li>
						<a href="apps_bank.html">Dashboard 4 <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="layouts_menu_top_image.html">Dashboard 5</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-hierarchy-structure-2">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Menu Styles</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-hierarchy-structure-2">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="layouts_menu_side.html">Side Menu Light</a>
					</li>
					<li>
						<a href="layouts_menu_side_dark.html">Side Menu Dark</a>
					</li>
					<li>
						<a href="apps_bank.html">Side Menu V2 <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_pipeline.html">Side &amp; Top Dark</a>
					</li>
					<li>
						<a href="apps_projects.html">Side &amp; Top <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					</ul>
					<ul class="sub-menu">
						<li>
						<a href="layouts_menu_side_compact.html">Compact Side Menu</a>
					</li>
					<li>
						<a href="layouts_menu_side_compact_dark.html">Compact Menu Dark</a>
					</li>
					<li>
						<a href="layouts_menu_top.html">Top Menu Light</a>
					</li>
					<li>
						<a href="layouts_menu_top_dark.html">Top Menu Dark</a>
					</li>
					<li>
						<a href="layouts_menu_top_image.html">Top Menu Image</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-delivery-box-2">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Applications</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-delivery-box-2">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="apps_email.html">Email Application</a>
					</li>
					<li>
						<a href="apps_support_dashboard.html">Support Dashboard <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_support_index.html">Tickets Index <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_projects.html">Projects List</a>
					</li>
					<li>
						<a href="apps_bank.html">Banking <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="apps_full_chat.html">Chat Application</a>
					</li>
					</ul>
					<ul class="sub-menu">
						<li>
						<a href="apps_todo.html">To Do Application <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="misc_chat.html">Popup Chat</a>
					</li>
					<li>
						<a href="apps_pipeline.html">CRM Pipeline</a>
					</li>
					<li>
						<a href="rentals_index_grid.html">Property Listing <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="misc_calendar.html">Calendar</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-newspaper">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Pages</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-newspaper">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="misc_invoice.html">Invoice</a>
					</li>
					<li>
						<a href="rentals_index_grid.html">Property Listing <strong class="badge badge-danger">New</strong>
					</a>
					</li>
					<li>
						<a href="misc_charts.html">Charts</a>
					</li>
					<li>
						<a href="auth_login.html">Login</a>
					</li>
					<li>
						<a href="auth_register.html">Register</a>
					</li>
					</ul>
					<ul class="sub-menu">
						<li>
						<a href="auth_lock.html">Lock Screen</a>
					</li>
					<li>
						<a href="misc_pricing_plans.html">Pricing Plans</a>
					</li>
					<li>
						<a href="misc_error_404.html">Error 404</a>
					</li>
					<li>
						<a href="misc_error_500.html">Error 500</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-pencil-12">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">UI Kit</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-pencil-12">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="uikit_modals.html">Modals</a>
					</li>
					<li>
						<a href="uikit_alerts.html">Alerts</a>
					</li>
					<li>
						<a href="uikit_grid.html">Grid</a>
					</li>
					<li>
						<a href="uikit_progress.html">Progress</a>
					</li>
					<li>
						<a href="uikit_popovers.html">Popover</a>
					</li>
					</ul>
					<ul class="sub-menu">
						<li>
						<a href="uikit_tooltips.html">Tooltips</a>
					</li>
					<li>
						<a href="uikit_buttons.html">Buttons</a>
					</li>
					<li>
						<a href="uikit_dropdowns.html">Dropdowns</a>
					</li>
					<li>
						<a href="uikit_typography.html">Typography</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-user-male-circle">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Users</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-user-male-circle">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="users_profile_big.html">Big Profile</a>
					</li>
					<li>
						<a href="users_profile_small.html">Compact Profile</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-tasks-checked">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Forms</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-tasks-checked">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="forms_regular.html">Regular Forms</a>
					</li>
					<li>
						<a href="forms_validation.html">Form Validation</a>
					</li>
					<li>
						<a href="forms_wizard.html">Form Wizard</a>
					</li>
					<li>
						<a href="forms_uploads.html">File Uploads</a>
					</li>
					<li>
						<a href="forms_wisiwig.html">Wisiwig Editor</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-grid-squares">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Tables</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-grid-squares">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="tables_regular.html">Regular Tables</a>
					</li>
					<li>
						<a href="tables_datatables.html">Data Tables</a>
					</li>
					<li>
						<a href="tables_editable.html">Editable Tables</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					<li class="has-sub-menu">
						<a href="#">
						<div class="icon-w">
						<i class="os-icon os-icon-robot-1">
					</i>
					</div>
					</a>
					<div class="sub-menu-w">
						<div class="sub-menu-title">Icons</div>
					<div class="sub-menu-icon">
						<i class="os-icon os-icon-robot-1">
					</i>
					</div>
					<div class="sub-menu-i">
						<ul class="sub-menu">
						<li>
						<a href="icon_fonts_simple_line_icons.html">Simple Line Icons</a>
					</li>
					<li>
						<a href="icon_fonts_themefy.html">Themefy Icons</a>
					</li>
					<li>
						<a href="icon_fonts_picons_thin.html">Picons Thin</a>
					</li>
					<li>
						<a href="icon_fonts_dripicons.html">Dripicons</a>
					</li>
					<li>
						<a href="icon_fonts_eightyshades.html">Eightyshades</a>
					</li>
					<li>
						<a href="icon_fonts_entypo.html">Entypo</a>
					</li>
					</ul>
					<ul class="sub-menu">
						<li>
						<a href="icon_fonts_font_awesome.html">Font Awesome</a>
					</li>
					<li>
						<a href="icon_fonts_foundation_icon_font.html">Foundation Icon Font</a>
					</li>
					<li>
						<a href="icon_fonts_metrize_icons.html">Metrize Icons</a>
					</li>
					<li>
						<a href="icon_fonts_picons_social.html">Picons Social</a>
					</li>
					<li>
						<a href="icon_fonts_batch_icons.html">Batch Icons</a>
					</li>
					<li>
						<a href="icon_fonts_dashicons.html">Dashicons</a>
					</li>
					</ul>
					<ul class="sub-menu">
						<li>
						<a href="icon_fonts_typicons.html">Typicons</a>
					</li>
					<li>
						<a href="icon_fonts_weather_icons.html">Weather Icons</a>
					</li>
					<li>
						<a href="icon_fonts_light_admin.html">Light Admin</a>
					</li>
					</ul>
					</div>
					</div>
					</li>
					</ul>
					</div>
					</div>
					<!--------------------
END - Menu side compact
-------------------->
					<div class="content-w">
						<div class="content-i">
						<div class="content-box">
						<div class="full-chat-w">
						<div class="full-chat-i">
						<div class="full-chat-left">
						<div class="os-tabs-w">
						<ul class="nav nav-tabs upper centered">
					<li class="nav-item">
						<a class="nav-link active" data-toggle="tab" href="#tab_sales">
						<i class="os-icon os-icon-ui-93">
					</i>
					<span>Contacts</span>
					</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#tab_overview">
						<i class="os-icon os-icon-mail-14">
					</i>
					<span>Chats</span>
					</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#tab_sales">
						<i class="os-icon os-icon-ui-02">
					</i>
					<span>Favorites</span>
					</a>
					</li>
					</ul>
					</div>
					<div class="chat-search">
						<div class="element-search">
						<input placeholder="Search users by name..." type="text">
					</div>
					</div>

					<div class="user-list">
						<?php
@$link=mysql_connect('localhost','root','');
    mysql_select_db("chatteit");


$sql= "SELECT * FROM users WHERE username != '{$_SESSION['username']}' ORDER BY etatuser DESC";
$result = mysql_query($sql, $link);

if (!$result) {
    echo "DB Error, could not query the database\n";
    echo 'MySQL Error: ' . mysql_error();
    exit;
}

while ($row = mysql_fetch_assoc($result)) {
                                                                     echo '<div class="user-w with-status status-green">
                                                                <div class="avatar">';

                                                                            if ($row["etatuser"] == "1") {
                                                                                    ?>
                                                                                    <!--<img src="images/connect.png">-->
                                                                            <?php
                                                                            }else{
                                                                                    ?>
                                                                                    <!--<img src="images/disconnect.png">-->
                                                                             <?PHP
                                                                            }
                                                                            ?>

                                                            <img alt="" src="<?PHP echo $row["imageuser"] ?>">
                                                            </div>
                                                            <div class="user-info">
                                                                <div class="user-date">12 min</div>
                                                                <style>
                                                            a {
														    color: black;
														      text-decoration: none;
																}
																a:hover {
														    color: black;
																}
                                                            </style>
                                                            <div class="user-name"> <a class="a" href="index.php?page=dashboard&&username=<?php echo $row["username"]?>"><strong><?php echo $row["firstname"]." ".$row["lastname"];?></strong></a></div>
                                                            <div class="last-message">What is going on, are we...</div>
                                                            </div>
                                                            </div>
                                                                 <br>
                                                                 <?PHP
												}
												mysql_free_result($result);

												?>

					</div>
					</div>
					<div class="full-chat-middle">
						<div class="chat-head">
						<div class="user-info">
						<span>Avec:</span>
						<?php
		  				if (!empty($_GET['username'])) {
		  					$sql = mysql_query("SELECT * FROM users WHERE username = '{$_GET['username']}' ORDER BY dateinscript ASC");
		  					$sqlrecup = mysql_fetch_array($sql);
		  					$queryname = $sqlrecup['firstname'];
		  					$queryname1 = $sqlrecup['lastname'];
		  					echo '<span><a href="">'.$queryname.' '.$queryname1.'</a></span>';
		  				}
		  		?>
					</div>
					<div class="user-actions">
						<a href="#">
						<i class="os-icon os-icon-mail-07">
					</i>
					</a>
					<a href="#">
						<i class="os-icon os-icon-phone-18">
					</i>
					</a>
					<a href="#">
						<i class="os-icon os-icon-phone-15">
					</i>
					</a>
					</div>
					</div>
					<script type="text/javascript">
						$(document).ready(function () {
          if (!$.browser.webkit) {
              $('.wrapper').html('<p>Sorry! Non webkit users. :(</p>');
          }
      });
									</script>

					<div class="chat-content-w">
						<div class="chat-content scrollbar" id="style-5">
						<div id="messageloadjs"></div>
					</div>
					</div>
					<form id="formmessagesub" method="POST" action="scriptphp/sendmassage.php">
	    				<input type="text" name="usersend" id="usersend" value="<?php echo $_SESSION['username'];?>" style="display:none">
	    				<input type="text" name="userrever" id="userrever" value="<?php if(!empty($_GET['username'])) echo $sqlrecup['username'];?>"  style="display:none">
					<div class="chat-controls">
						<div class="chat-input">
						<input id="massagesendjs" name="massagesendjs" placeholder="Type your message here..." type="text">
					</div>
					<div class="chat-input-extra">
						<div class="chat-extra-actions">
						<a href="#">
						<i class="os-icon os-icon-mail-07">
					</i>
					</a>
					<a href="#">
						<i class="os-icon os-icon-phone-18">
					</i>
					</a>
					<a href="#">
						<i class="os-icon os-icon-phone-15">
					</i>
					</a>
					</div>
					<div class="chat-btn">
						<a type="submit" id="submitinserteuser" name="submitinserteuser" class="btn btn-primary" href="#">Envoyer</a>
					</div>
					</div>
					</div>
					</form>
					</div>
					<div class="full-chat-right">
						<div class="user-intro">
						<div class="avatar">
							<?php
		  				if (!empty($_GET['username'])) {
		  					$sql = mysql_query("SELECT * FROM users WHERE username = '{$_GET['username']}' ORDER BY dateinscript ASC");
		  					$sqlrecup = mysql_fetch_array($sql);
		  					$queryname = $sqlrecup['firstname'];
		  					$queryname1 = $sqlrecup['lastname'];
		  					$queryimg = $sqlrecup['imageuser'];

		  		?>
						<img alt="" src="<?PHP echo $queryimg;?>">
					</div>
					<div class="user-intro-info">
						<?php
		  					echo '<h5 class="user-name"><a href="" style="text-decoration:none">'.$queryname.' '.$queryname1.'</a></h5>';
		  				}
		  		?>
					<div class="user-sub">Algérie</div>
					<div class="user-social">
						<a href="#">
						<i class="os-icon os-icon-twitter">
					</i>
					</a>
					<a href="#">
						<i class="os-icon os-icon-facebook">
					</i>
					</a>
					</div>
					</div>
					<div class="element-wrapper">
<h6 class="element-header">Utilisateurs</h6>
<div class="element-box-tp">

<div class="profile-tile">
<div class="profile-tile-box">
<div class="pt-avatar-w">
<img alt="" src="img/avatar3.jpg">
</div>
<div class="pt-user-name">John Mayers</div>
</div>
<div class="profile-tile-meta">
<ul>
<li>Statut:<strong>Online Now</strong>
</li>
<li>Tickets:<strong>9</strong>
</li>
<li>Response Time:<strong>3 hours</strong>
</li>
</ul>
<div class="pt-btn">
<a class="btn btn-secondary btn-sm" href="#">Send Message</a>
</div>
</div>
</div>
</div>
</div>
					</div>
					<div class="chat-info-section">
						<div class="ci-header">
						<i class="os-icon os-icon-documents-03">
					</i>
					<span>Shared Files</span>
					</div>
					<div class="ci-content">
						<div class="ci-file-list">
						<ul>
						<li>
						<a href="#">Annual Revenue.pdf</a>
					</li>
					<li>
						<a href="#">Expenses.xls</a>
					</li>
					<li>
						<a href="#">Business Plan.doc</a>
					</li>
					</ul>
					</div>
					</div>
					</div>
					<div class="chat-info-section">
						<div class="ci-header">
						<i class="os-icon os-icon-documents-07">
					</i>
					<span>Shared Photos</span>
					</div>
					<div class="ci-content">
						<div class="ci-photos-list">
						<img alt="" src="img/portfolio9.jpg">
					<img alt="" src="img/portfolio2.jpg">
					<img alt="" src="img/portfolio12.jpg">
					<img alt="" src="img/portfolio14.jpg">
					</div>
					</div>
					</div>
										</div>
					</div>
					</div>
					<!--------------------
START - Chat Popup Box
-------------------->
					<div class="floated-chat-btn">
						<i class="os-icon os-icon-mail-07">
					</i>
					<span>Demo Chat</span>
					</div>
					<div class="floated-chat-w">
						<div class="floated-chat-i">
						<div class="chat-close">
						<i class="os-icon os-icon-close">
					</i>
					</div>
					<?PHP $sql = mysql_query("SELECT imageuser FROM users WHERE username = '{$_GET['username']}' ORDER BY dateinscript ASC");
		  					$sqlrecup = mysql_fetch_array($sql);
		  					$queryimage = $sqlrecup['imageuser'];
		  					 ?>
					<div class="chat-head">
						<div class="user-w with-status status-green">
						<div class="user-avatar-w">
						<div class="user-avatar">
						<img alt="" src="<?PHP echo $queryimage;?>">
					</div>
					</div>
					<div class="user-name">
						<h6 class="user-title"><?PHP echo '<span><a href="" style="text-decoration:none">'.$queryname.' '.$queryname1.'</a></span>'; ?></h6>
					<div class="user-role">Account Manager</div>
					</div>
					</div>
					</div>
					<div class="chat-messages">
					<!--<div class="date-break">Mon 10:20am</div>-->
					</div>
					<div class="chat-controls">
						<input class="message-input" placeholder="Type your message here..." type="text">
					<div class="chat-extra">
						<a href="#">
						<span class="extra-tooltip">Attach Document</span>
					<i class="os-icon os-icon-documents-07">
					</i>
					</a>
					<a href="#">
						<span class="extra-tooltip">Insert Photo</span>
					<i class="os-icon os-icon-others-29">
					</i>
					</a>
					<a href="#">
						<span class="extra-tooltip">Upload Video</span>
					<i class="os-icon os-icon-ui-51">
					</i>
					</a>
					</div>
					</div>
					</div>
					</div>
					<!--------------------
END - Chat Popup Box
-------------------->
					</div>
					</div>
					</div>
					</div>
					<div class="display-type">
					</div>
					</div>
					<script src="bower_components/jquery/dist/jquery.min.js">
					</script>
					<script src="bower_components/moment/moment.js">
					</script>
					<script src="bower_components/chart.js/dist/Chart.min.js">
					</script>
					<script src="bower_components/select2/dist/js/select2.full.min.js">
					</script>
					<script src="bower_components/jquery-bar-rating/dist/jquery.barrating.min.js">
					</script>
					<script src="bower_components/ckeditor/ckeditor.js">
					</script>
					<script src="bower_components/bootstrap-validator/dist/validator.min.js">
					</script>
					<script src="bower_components/bootstrap-daterangepicker/daterangepicker.js">
					</script>
					<script src="bower_components/ion.rangeSlider/js/ion.rangeSlider.min.js">
					</script>
					<script src="bower_components/dropzone/dist/dropzone.js">
					</script>
					<script src="bower_components/editable-table/mindmup-editabletable.js">
					</script>
					<script src="bower_components/datatables.net/js/jquery.dataTables.min.js">
					</script>
					<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js">
					</script>
					<script src="bower_components/fullcalendar/dist/fullcalendar.min.js">
					</script>
					<script src="bower_components/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js">
					</script>
					<script src="bower_components/tether/dist/js/tether.min.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/util.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/alert.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/button.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/carousel.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/collapse.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/dropdown.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/modal.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/tab.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/tooltip.js">
					</script>
					<script src="bower_components/bootstrap/js/dist/popover.js">
					</script>
					<script src="js/main4e09.js?version=3.7.0">
					</script>
					<script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','../www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-42863888-9', 'auto');
ga('send', 'pageview');</script>
					</body>
<!-- Mirrored from light.pinsupreme.com/apps_full_chat.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 25 Dec 2017 17:51:27 GMT -->
</html>
