<?php
	mysql_query("UPDATE users SET etatuser ='0' WHERE username = '{$_GET['usersession']}'")  or die(mysql_error());
	deconnection();
	header("Location:index.php?page=login");
?>