<?php
  function deconnection(){
	session_destroy();
	}
 ?>