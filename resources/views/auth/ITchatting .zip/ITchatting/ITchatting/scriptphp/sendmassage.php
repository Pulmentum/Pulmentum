<?php
	include('../functions/connexion.php');
	if ($_POST) {
		$usersend = mysql_real_escape_string(htmlspecialchars(trim($_POST['usersend'])));
		$userrever = mysql_real_escape_string(htmlspecialchars(trim($_POST['userrever'])));
		$massagesendjs = mysql_real_escape_string(htmlspecialchars(trim($_POST['massagesendjs'])));

		$sql= "INSERT INTO chattable VALUES('','$usersend','$userrever','$massagesendjs',NOW())";
		mysql_query($sql);
	}
?>