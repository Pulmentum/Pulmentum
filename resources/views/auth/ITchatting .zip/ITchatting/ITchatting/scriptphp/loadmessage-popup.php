<?php
    include('../functions/connexion.php');

            function info_recuper_recupemessage(){
             $infos = array();
             //$usersend
             $query = mysql_query("SELECT * FROM chattable WHERE usersend = '{$_GET['usersend']}' AND userrecive = '{$_GET['userrever']}' || usersend = '{$_GET['userrever']}' AND userrecive = '{$_GET['usersend']}' ORDER BY idchat ") or die(mysql_error());
             while($rows = mysql_fetch_assoc($query)){
                 $infos[]=$rows;
             }
             return $infos;
            }

            $infos = info_recuper_recupemessage();
            foreach ($infos as $info) {
                  if ($info['usersend'] == $_GET['usersend']) {
                        ?>
                            <div class="message">
                        <div class="message-content"><?php echo $info['message'];?></div>
                          </div>
                        <?php
                  }else{
                        ?>
                        <div class="message self">
                        <div class="message-content"><?php echo $info['message'];?></div>
                      </div>
                       <script type="text/javascript">
                                    function getMessages(letter) {
                            var div = $("#style-5");
                            div.scrollTop(div.prop('scrollHeight'));
                        }

                        $(function() {
                            getMessages();
                        });
                        </script>
                        <?php
                  }
            }
?>
