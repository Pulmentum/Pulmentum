<?php
include('../functions/connexion.php');
$valid['success'] = array('success' => false, 'message' => array());
if ($_POST) {

	$firstname = mysql_real_escape_string(htmlspecialchars(trim($_POST['firstname'])));
	$Lastname = mysql_real_escape_string(htmlspecialchars(trim($_POST['Lastname'])));
	$emailuser = mysql_real_escape_string(htmlspecialchars(trim($_POST['emailuser'])));
	$numberphone = mysql_real_escape_string(htmlspecialchars(trim($_POST['firstname'])));
	$usernames = mysql_real_escape_string(htmlspecialchars(trim($_POST['usernames'])));
	$passwords = md5(mysql_real_escape_string(htmlspecialchars(trim($_POST['passwords']))));

		$image = explode('.', $_FILES['imageuser']['name']);
		$image = $image[count($image) - 1];
		$url = '../avatar/'.uniqid(rand()).'.'.$image;
		$url2 = substr($url, 3);

		$query=mysql_query("SELECT emailuser,username FROM users WHERE emailuser = '$emailuser' || username = '$usernames'");
		$rows = mysql_fetch_row($query);


		if ($rows > 0)
			$valid['success'] = false;
			$valid['message'] = 'Error! Some parameters already exert to another user';
			
		if ($rows == 0){
			if (in_array($image, array('gif', 'jpeg','png','jpg', 'JPG', 'GIF', 'JPEG', 'PNG'))) {
				if (is_uploaded_file($_FILES['imageuser']['tmp_name'])) {
					if (move_uploaded_file($_FILES['imageuser']['tmp_name'], $url)) {
						//insertion in data base ..................
						$sql = "INSERT INTO users VALUES('','$firstname','$Lastname','$emailuser','$url2','$usernames','$passwords','0','1',NOW())";
						if (mysql_query($sql) === TRUE) {
											$valid['success'] = true;
											$valid['message'] = "Your account has been created";											
									}else{
											$valid['success'] = false;
											$valid['message'] = "Error creating account, please retry";
											//header("Location:index.php?page=article");									
									}					
					}
				}
			}
		}	
	echo json_encode($valid);
}
?>