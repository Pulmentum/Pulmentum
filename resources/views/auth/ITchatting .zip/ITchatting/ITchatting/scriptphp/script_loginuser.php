<?php

	include('../functions/connexion.php');
	$username = mysql_real_escape_string(htmlspecialchars(trim($_POST['username'])));
	$password = md5(mysql_real_escape_string(htmlspecialchars(trim($_POST['password']))));


		$query=mysql_query("SELECT username,password FROM users WHERE username = '$username' AND password = '$password'");
		$rows = mysql_fetch_row($query);

		if ($rows <= 0) {
			echo 0;
		}else{
			mysql_query("UPDATE users SET etatuser ='1' WHERE username = '{$_SESSION['username']}'")  or die(mysql_error());
			echo 1;
			$_SESSION['username'] = $username;
		}

?>